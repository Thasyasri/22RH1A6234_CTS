Exercise 1.2: Set up a project using npm or downloaded Bootstrap files. Use the downloaded files in a sample HTML page.

Bootstrap is installed via npm, we linked the CSS and JS files from the node_modules folder. Instead of using the CDN link, we are now using the files from the node_modules folder.

After running npm install bootstrap, you’ll see the node_modules folder in your project directory.
>> The correct paths to Bootstrap's CSS and JS files are:
>> node_modules/bootstrap/dist/css/bootstrap.min.css
>> node_modules/bootstrap/dist/js/bootstrap.min.js
>> node_modules/@popperjs/core/dist/umd/popper.min.js (for Popper.js)

Exercise 2.1: Explore the structure of the downloaded Bootstrap directory. Identify and explain the purpose of the CSS, JS, and icons folders.

bootstrap-5.x.x-dist/
    ├── css/
    │   ├── bootstrap.min.css
    │   ├── bootstrap.rtl.min.css
    │   └── bootstrap.min.css.map
    ├── js/
    │   ├── bootstrap.bundle.min.js
    │   ├── bootstrap.bundle.min.js.map
    │   ├── bootstrap.min.js
    │   └── bootstrap.min.js.map
    └── icons/
        ├── font/bootstrap-icons.css
        └── fonts/
            ├── bootstrap-icons.woff
            ├── bootstrap-icons.woff2

CSS Folder: Contains all styles needed for Bootstrap's grid system, layout, and components.

JS Folder: Contains the necessary JavaScript to enable interactive components like dropdowns, modals, carousels, etc.

Icons Folder: Contains the CSS and font files needed for Bootstrap icons.

Exercise 2.2: Modify your HTML to include Bootstrap's JavaScript plugins via bootstrap.bundle.min.js.

bootstrap.bundle.min.js: By using this file, you are ensuring that all Bootstrap components requiring JavaScript (such as dropdowns, modals, tooltips, etc.) will work, without needing to load Popper.js separately.

Exercise 3:

> The layout uses the .container class to keep the content centered and properly spaced.
> Inside the .row, we have six columns.
> On mobile screens, all columns take full width (col-12), so they stack vertically.
> On medium screens (tablets), each column takes up half the row (col-md-6), so there will be 2 columns per row.
> On large screens (desktops), each column takes up one-third of the row (col-lg-4), so 3 columns will fit per row.

Exercise 4.1:
we are creating a two-column layout where one column will act as a sidebar (with a width of col-md-3), and the other will be the content area (with a width of col-md-9).

> .container: The container class ensures that the content is centered and has proper padding around it.
> .row: This creates a horizontal group for the columns (sidebar and content area).
> .col-md-3: This class sets the sidebar width to 3 columns on medium and larger screens (with a 12-column grid, 3 out of 12 columns are taken by the sidebar).
> .col-md-9: This class sets the content area width to 9 columns on medium and larger screens, leaving 3 columns for the sidebar.
> p-3: Padding utility to add some padding to the content inside the columns.
> border and bg-light: Utility classes to give the sidebar and content area a border and light background color, respectively.

Exercise 4.2:
we’ll create a four-column layout, where each column will take up 3 grid units (so col-sm-3 will divide the screen into four equal columns).

> .col-sm-3: This class tells Bootstrap to create columns that take up 3 grid units each on small screens and above. Since the grid is 12 units wide, col-sm-3 ensures there will be 4 equal columns in total.
> .row: This wraps the columns in a row to properly align them horizontally.
> .container: This keeps the layout centered and adds padding around the content.
> p-3: Padding utility to space the content inside the columns.
> border and bg-light: These are used for adding borders and background color to the columns for better visualization.

Exercise 5.1:

we will use Bootstrap's utility classes to center content both horizontally and vertically inside a row.

Exercise 5.2:

 we will reorder the columns on medium-sized screens using the order-md-* classes.

Exercise 6.1:
Exercise 6.2: