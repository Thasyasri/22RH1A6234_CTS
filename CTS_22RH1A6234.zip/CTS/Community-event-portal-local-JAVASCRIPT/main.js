// Event Constructor Class
class Event {
    constructor(name, date, seats, category) {
        this.name = name;
        this.date = date;
        this.seats = seats;
        this.category = category;
    }

    // Method to check availability
    checkAvailability() {
        return this.seats > 0;
    }

    // Method to register (decrease seats)
    register() {
        if (this.checkAvailability()) {
            this.seats--;
            return true;
        }
        return false;
    }
}

// Sample events array
let events = [
    new Event("Music Festival", "2025-06-15", 100, "Music"),
    new Event("Art Exhibition", "2025-05-25", 0, "Art"),
    new Event("Workshop on Painting", "2025-06-10", 50, "Workshop"),
    new Event("Sports Tournament", "2025-06-20", 200, "Sports"),
];

// Display events dynamically
function displayEvents(eventArray) {
    const eventListContainer = document.getElementById("eventList");
    eventListContainer.innerHTML = ""; // Clear current events

    eventArray.forEach(event => {
        if (event.checkAvailability()) {
            const eventCard = document.createElement("div");
            eventCard.classList.add("event-card");
            eventCard.innerHTML = `
                <h3>${event.name}</h3>
                <p>Date: ${event.date}</p>
                <p>Category: ${event.category}</p>
                <p>Seats Available: ${event.seats}</p>
                <button onclick="registerForEvent('${event.name}')">Register</button>
            `;
            eventListContainer.appendChild(eventCard);
        }
    });
}

// Register for an event - redirect to form
function registerForEvent(eventName) {
    const event = events.find(e => e.name === eventName);
    if (event && event.checkAvailability()) {
        // Pre-fill the registration form with event details
        document.getElementById("eventName").value = event.name;
        document.getElementById("eventDate").value = event.date;

        // Scroll to the registration section
        document.getElementById("events").scrollIntoView({ behavior: "smooth" });
    } else {
        alert(`${eventName} is full or unavailable.`);
    }
}

// Handle form submission
function submitRegistration(event) {
    event.preventDefault(); // Prevent default form submission

    // Get form data
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const eventName = document.getElementById('eventName').value;
    const eventDate = document.getElementById('eventDate').value;
    const message = document.getElementById('message').value;

    // Find the selected event
    const selectedEvent = events.find(e => e.name === eventName);

    // Register the user if possible
    if (selectedEvent && selectedEvent.register()) {
        // Show confirmation message
        const confirmationText = `
            Thank you for registering, ${name}!
            <br>We have received your registration for the ${eventName} event scheduled for ${eventDate}.
            <br>A confirmation email will be sent to ${email}.
            <br>Your message: "${message || 'No message provided'}"
        `;
        document.getElementById('confirmation').innerHTML = confirmationText;

        // Clear form fields after submission
        document.querySelector('form').reset();
        displayEvents(events); // Re-render events with updated seat count
    } else {
        alert("Sorry, this event is full or unavailable.");
    }
}

// Filter events by category
function filterEventsByCategory() {
    const category = document.getElementById("eventCategory").value;
    const filteredEvents = category
        ? events.filter(event => event.category === category)
        : events;
    displayEvents(filteredEvents);
}

// Initial display of all events
window.onload = function() {
    displayEvents(events);
};

// Find nearby events using geolocation
function findNearbyEvents() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            function(position) {
                const latitude = position.coords.latitude;
                const longitude = position.coords.longitude;
                document.getElementById("geoLocationMessage").textContent = `Your Location: Latitude: ${latitude}, Longitude: ${longitude}`;
            },
            function(error) {
                document.getElementById("geoLocationMessage").textContent = "Geolocation permission denied. Please allow location access.";
            },
            { enableHighAccuracy: true, timeout: 5000, maximumAge: 0 }
        );
    } else {
        document.getElementById("geoLocationMessage").textContent = "Geolocation is not supported by your browser.";
    }
}
