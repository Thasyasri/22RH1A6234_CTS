import java.util.ArrayList;
import java.util.Scanner;

public class StudentListExample {

    public static void main(String[] args) {
        // Create an ArrayList to store student names
        ArrayList<String> studentNames = new ArrayList<>();

        // Create a scanner object to read user input
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter student names
        System.out.println("Enter student names (type 'done' to finish):");

        while (true) {
            System.out.print("Enter a name: ");
            String name = scanner.nextLine();

            // If the user types 'done', exit the loop
            if (name.equalsIgnoreCase("done")) {
                break;
            }

            // Add the name to the ArrayList
            studentNames.add(name);
        }

        // Display all the names entered
        System.out.println("\nList of student names entered:");
        for (String student : studentNames) {
            System.out.println(student);
        }

        // Close the scanner to prevent resource leak
        scanner.close();
    }
}
