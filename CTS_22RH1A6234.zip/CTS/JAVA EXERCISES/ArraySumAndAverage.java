import java.util.Scanner;

public class ArraySumAndAverage {
    public static void main(String[] args) {
        // Create a Scanner object for user input
        Scanner scanner = new Scanner(System.in);

        // Prompt the user for the number of elements
        System.out.print("Enter the number of elements: ");
        int numElements = scanner.nextInt();

        // Declare an array to store the elements
        int[] numbers = new int[numElements];

        // Read the elements into the array
        System.out.println("Enter the elements:");
        for (int i = 0; i < numElements; i++) {
            numbers[i] = scanner.nextInt();
        }

        // Calculate the sum of the elements
        int sum = 0;
        for (int num : numbers) {
            sum += num;
        }

        // Calculate the average
        double average = (double) sum / numElements;

        // Display the sum and average
        System.out.println("Sum of the elements: " + sum);
        System.out.println("Average of the elements: " + average);

        // Close the scanner
        scanner.close();
    }
}
