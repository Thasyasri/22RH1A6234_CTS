import java.sql.*;

public class BankTransactionExample {

    private static final String URL = "jdbc:mysql://localhost:3306/bank"; // Your DB URL
    private static final String USER = "root"; // MySQL username
    private static final String PASSWORD = "password"; // MySQL password

    public static void main(String[] args) {
        // Example: Transfer money from Account1 to Account2
        BankTransactionExample bankTransaction = new BankTransactionExample();
        bankTransaction.transferMoney(1, 2, 200.00); // Transfer 200 from Account1 to Account2
    }

    // Method to transfer money from one account to another
    public void transferMoney(int fromAccountId, int toAccountId, double amount) {
        Connection connection = null;
        PreparedStatement debitStatement = null;
        PreparedStatement creditStatement = null;

        try {
            // Step 1: Establish the connection
            connection = DriverManager.getConnection(URL, USER, PASSWORD);

            // Step 2: Set auto-commit to false to begin the transaction
            connection.setAutoCommit(false);

            // Step 3: Create the SQL statements for debit and credit
            String debitQuery = "UPDATE accounts SET balance = balance - ? WHERE id = ?";
            String creditQuery = "UPDATE accounts SET balance = balance + ? WHERE id = ?";

            // Prepare the statements
            debitStatement = connection.prepareStatement(debitQuery);
            creditStatement = connection.prepareStatement(creditQuery);

            // Step 4: Debit from the first account
            debitStatement.setDouble(1, amount);
            debitStatement.setInt(2, fromAccountId);
            int debitRowsAffected = debitStatement.executeUpdate();

            // Step 5: Credit to the second account
            creditStatement.setDouble(1, amount);
            creditStatement.setInt(2, toAccountId);
            int creditRowsAffected = creditStatement.executeUpdate();

            // Step 6: Check if both operations were successful
            if (debitRowsAffected == 1 && creditRowsAffected == 1) {
                // Both debit and credit were successful, commit the transaction
                connection.commit();
                System.out.println("Transaction successful: " + amount + " transferred.");
            } else {
                // Something went wrong, roll back the transaction
                connection.rollback();
                System.out.println("Transaction failed: rolling back.");
            }

        } catch (SQLException e) {
            // Handle SQL exceptions (e.g., connection issues, query errors)
            try {
                if (connection != null) {
                    connection.rollback(); // Rollback if any exception occurs
                    System.out.println("Transaction rolled back due to error.");
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
        } finally {
            // Step 7: Clean up the resources
            try {
                if (debitStatement != null) debitStatement.close();
                if (creditStatement != null) creditStatement.close();
                if (connection != null) connection.setAutoCommit(true); // Reset auto-commit to true
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
