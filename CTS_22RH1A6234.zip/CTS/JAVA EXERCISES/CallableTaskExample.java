import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class CallableTaskExample {

    public static void main(String[] args) {
        // Create an ExecutorService with a fixed thread pool of 3 threads
        ExecutorService executor = Executors.newFixedThreadPool(3);

        // Create and submit multiple Callable tasks
        Callable<String> task1 = new MyCallableTask(1);
        Callable<String> task2 = new MyCallableTask(2);
        Callable<String> task3 = new MyCallableTask(3);

        // Submit tasks to the executor and get Future objects
        Future<String> result1 = executor.submit(task1);
        Future<String> result2 = executor.submit(task2);
        Future<String> result3 = executor.submit(task3);

        try {
            // Retrieve the results using Future.get()
            System.out.println("Result from task1: " + result1.get());
            System.out.println("Result from task2: " + result2.get());
            System.out.println("Result from task3: " + result3.get());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Shutdown the executor service
            executor.shutdown();
        }
    }
}

// A simple Callable task that returns a message
class MyCallableTask implements Callable<String> {

    private int taskId;

    public MyCallableTask(int taskId) {
        this.taskId = taskId;
    }

    @Override
    public String call() throws Exception {
        // Simulating some task execution with sleep
        Thread.sleep(2000); // Simulating a delay
        return "Task " + taskId + " completed";
    }
}
