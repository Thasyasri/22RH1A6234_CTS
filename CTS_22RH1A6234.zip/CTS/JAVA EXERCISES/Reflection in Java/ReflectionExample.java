import java.lang.reflect.Method;
import java.lang.reflect.Parameter;

public class ReflectionExample {

    public static void main(String[] args) {
        try {
            // Load the SampleClass dynamically
            Class<?> clazz = Class.forName("SampleClass");

            // Get all declared methods (including private methods, if any)
            Method[] methods = clazz.getDeclaredMethods();

            // Print method names and parameters
            System.out.println("Methods of class: " + clazz.getName());
            for (Method method : methods) {
                System.out.print("Method name: " + method.getName() + " | Parameters: ");
                
                // Print parameter types
                Parameter[] parameters = method.getParameters();
                for (Parameter parameter : parameters) {
                    System.out.print(parameter.getType().getName() + " " + parameter.getName() + " ");
                }
                System.out.println();
            }

            // Create an instance of SampleClass using reflection (for non-static methods)
            Object obj = clazz.getDeclaredConstructor().newInstance();

            // Invoke non-static methods
            Method sayHelloMethod = clazz.getMethod("sayHello");
            sayHelloMethod.invoke(obj);  // No parameters

            // Invoke the method with parameters
            Method greetMethod = clazz.getMethod("greet", String.class, int.class);
            greetMethod.invoke(obj, "Alice", 25);  // Parameters: "Alice", 25

            // Invoke the static method
            Method staticMethod = clazz.getMethod("staticMethod");
            staticMethod.invoke(null);  // Static methods are invoked with null as the object

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
