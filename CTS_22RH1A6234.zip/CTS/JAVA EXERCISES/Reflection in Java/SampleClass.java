public class SampleClass {

    // A method with no parameters
    public void sayHello() {
        System.out.println("Hello, World!");
    }

    // A method with parameters
    public void greet(String name, int age) {
        System.out.println("Hello, " + name + ". You are " + age + " years old.");
    }

    // A static method
    public static void staticMethod() {
        System.out.println("This is a static method.");
    }
}
