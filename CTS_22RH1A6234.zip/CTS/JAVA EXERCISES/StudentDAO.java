import java.sql.*;

public class StudentDAO {
    private static final String URL = "jdbc:mysql://localhost:3306/school"; // Your DB URL
    private static final String USER = "root"; // MySQL username
    private static final String PASSWORD = "password"; // MySQL password

    // Method to insert a new student record
    public void insertStudent(Student student) {
        String query = "INSERT INTO students (name, age) VALUES (?, ?)";

        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            // Set the parameters for the insert query
            preparedStatement.setString(1, student.getName());
            preparedStatement.setInt(2, student.getAge());

            // Execute the query
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Student inserted successfully.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to update a student's details
    public void updateStudent(Student student) {
        String query = "UPDATE students SET name = ?, age = ? WHERE id = ?";

        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            // Set the parameters for the update query
            preparedStatement.setString(1, student.getName());
            preparedStatement.setInt(2, student.getAge());
            preparedStatement.setInt(3, student.getId());

            // Execute the query
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Student updated successfully.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
