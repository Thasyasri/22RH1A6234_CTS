import java.util.Scanner;
import java.util.Random;

public class NumberGuessingGame {
    public static void main(String[] args) {
        // Create a Scanner object for user input
        Scanner scanner = new Scanner(System.in);
        
        // Generate a random number between 1 and 100
        Random random = new Random();
        int targetNumber = random.nextInt(100) + 1; // Generates a number from 1 to 100
        
        int userGuess = 0; // Initialize user guess
        int attempts = 0;  // Track number of attempts

        // Prompt the user to guess the number
        System.out.println("Welcome to the Number Guessing Game!");
        System.out.println("I have selected a number between 1 and 100. Try to guess it!");

        // Loop until the user guesses correctly
        while (userGuess != targetNumber) {
            // Prompt user to enter a guess
            System.out.print("Enter your guess: ");
            userGuess = scanner.nextInt();
            attempts++; // Increment attempt count

            // Provide feedback
            if (userGuess < targetNumber) {
                System.out.println("Too low! Try again.");
            } else if (userGuess > targetNumber) {
                System.out.println("Too high! Try again.");
            } else {
                System.out.println("Congratulations! You've guessed the number in " + attempts + " attempts.");
            }
        }

        // Close the scanner
        scanner.close();
    }
}

