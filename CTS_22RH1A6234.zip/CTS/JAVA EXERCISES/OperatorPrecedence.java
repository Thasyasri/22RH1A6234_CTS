public class OperatorPrecedence {
    public static void main(String[] args) {
        // Expression 1: Combining addition and multiplication
        int result1 = 10 + 5 * 2;
        // Multiplication happens first, then addition.
        System.out.println("Expression 1: 10 + 5 * 2 = " + result1); // Expected result: 10 + (5 * 2) = 10 + 10 = 20

        // Expression 2: Combining subtraction and division
        int result2 = 20 - 6 / 2;
        // Division happens first, then subtraction.
        System.out.println("Expression 2: 20 - 6 / 2 = " + result2); // Expected result: 20 - (6 / 2) = 20 - 3 = 17

        // Expression 3: Combining parentheses with multiplication and addition
        int result3 = (10 + 5) * 2;
        // Parentheses have the highest precedence, so addition happens first.
        System.out.println("Expression 3: (10 + 5) * 2 = " + result3); // Expected result: (10 + 5) * 2 = 15 * 2 = 30

        // Expression 4: Combining modulus and subtraction
        int result4 = 15 % 4 - 2;
        // Modulus happens first, then subtraction.
        System.out.println("Expression 4: 15 % 4 - 2 = " + result4); // Expected result: (15 % 4) - 2 = 3 - 2 = 1

        // Expression 5: Combining all operators (addition, multiplication, division)
        int result5 = 10 + 5 * 3 / 2;
        // Multiplication and division happen first (left to right), then addition.
        System.out.println("Expression 5: 10 + 5 * 3 / 2 = " + result5); // Expected result: 10 + ((5 * 3) / 2) = 10 + 15 / 2 = 10 + 7 = 17
    }
}
