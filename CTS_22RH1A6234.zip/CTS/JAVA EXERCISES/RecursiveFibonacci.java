import java.util.Scanner;

public class RecursiveFibonacci {

    // Recursive method to calculate the nth Fibonacci number
    public static int fibonacci(int n) {
        // Base case: Fibonacci of 0 is 0, and Fibonacci of 1 is 1
        if (n <= 1) {
            return n;
        }
        // Recursive case: Fibonacci of n is Fibonacci of (n-1) + Fibonacci of (n-2)
        return fibonacci(n - 1) + fibonacci(n - 2);
    }

    public static void main(String[] args) {
        // Create a Scanner object for user input
        Scanner scanner = new Scanner(System.in);

        // Prompt the user for a positive integer n
        System.out.print("Enter a positive integer: ");
        int n = scanner.nextInt();

        // Call the fibonacci method and display the result
        int result = fibonacci(n);
        System.out.println("The " + n + "th Fibonacci number is: " + result);

        // Close the scanner
        scanner.close();
    }
}
