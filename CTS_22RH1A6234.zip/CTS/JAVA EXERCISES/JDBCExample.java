import java.sql.*;

public class JDBCExample {

    public static void main(String[] args) {
        // MySQL database URL, username, and password
        String url = "jdbc:mysql://localhost:3306/school"; // Change to your DB's URL and name
        String user = "root"; // MySQL username
        String password = "password"; // MySQL password

        // Connection and Statement objects
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            // Step 1: Load the JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Step 2: Establish the connection
            connection = DriverManager.getConnection(url, user, password);

            // Step 3: Create a statement
            statement = connection.createStatement();

            // Step 4: Execute the SELECT query
            String query = "SELECT * FROM students";
            resultSet = statement.executeQuery(query);

            // Step 5: Process the result set
            System.out.println("ID\tName\t\tAge");
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                int age = resultSet.getInt("age");
                System.out.println(id + "\t" + name + "\t" + age);
            }
        } catch (ClassNotFoundException e) {
            System.out.println("JDBC Driver not found: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("Database error: " + e.getMessage());
        } finally {
            // Step 6: Close resources
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                System.out.println("Error closing resources: " + e.getMessage());
            }
        }
    }
}
