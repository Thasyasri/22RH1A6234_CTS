// Define the custom exception class
class InvalidAgeException extends Exception {
    // Constructor to pass a message when the exception is thrown
    public InvalidAgeException(String message) {
        super(message);
    }
}

public class CustomExceptionExample {

    public static void main(String[] args) {
        // Create a scanner object to read user input
        java.util.Scanner scanner = new java.util.Scanner(System.in);

        // Prompt the user for their age
        System.out.print("Enter your age: ");
        int age = scanner.nextInt();

        try {
            // Check if the age is less than 18, throw InvalidAgeException
            if (age < 18) {
                throw new InvalidAgeException("Age must be 18 or older.");
            }
            // If no exception is thrown, print a message
            System.out.println("Age is valid.");
        } catch (InvalidAgeException e) {
            // Catch the custom exception and display the message
            System.out.println("Error: " + e.getMessage());
        } finally {
            // Close the scanner to prevent resource leak
            scanner.close();
        }
    }
}
