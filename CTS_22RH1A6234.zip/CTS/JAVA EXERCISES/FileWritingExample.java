import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class FileWritingExample {

    public static void main(String[] args) {
        // Create a scanner object to read user input
        Scanner scanner = new Scanner(System.in);

        // Prompt the user for a string
        System.out.print("Enter a string to write to the file: ");
        String userInput = scanner.nextLine();

        // Try block for writing data to the file
        try (FileWriter fileWriter = new FileWriter("output.txt")) {
            // Write the string to the file
            fileWriter.write(userInput);

            // Confirm that the data has been written
            System.out.println("Data has been written to output.txt");
        } catch (IOException e) {
            // Handle any IO exceptions
            System.out.println("An error occurred while writing to the file: " + e.getMessage());
        } finally {
            // Close the scanner to prevent resource leaks
            scanner.close();
        }
    }
}
