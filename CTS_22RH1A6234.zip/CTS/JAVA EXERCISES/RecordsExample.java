import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

// Define the Person record
public record Person(String name, int age) {}

public class RecordsExample {

    public static void main(String[] args) {
        // Create a list of Person records
        List<Person> people = new ArrayList<>();
        people.add(new Person("Alice", 30));
        people.add(new Person("Bob", 25));
        people.add(new Person("Charlie", 35));
        people.add(new Person("Diana", 28));
        
        // Print all the Person records
        System.out.println("All People:");
        people.forEach(person -> System.out.println(person));
        
        // Filter people by age (e.g., those older than 30)
        List<Person> filteredPeople = people.stream()
                                            .filter(person -> person.age() > 30)  // Filter by age
                                            .collect(Collectors.toList());  // Collect the filtered results
        
        // Print the filtered list
        System.out.println("\nPeople older than 30:");
        filteredPeople.forEach(person -> System.out.println(person));
    }
}
