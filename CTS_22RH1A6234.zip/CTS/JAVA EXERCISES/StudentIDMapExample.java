import java.util.HashMap;
import java.util.Scanner;

public class StudentIDMapExample {

    public static void main(String[] args) {
        // Create a HashMap to map student IDs (Integer) to student names (String)
        HashMap<Integer, String> studentMap = new HashMap<>();

        // Create a scanner object to read user input
        Scanner scanner = new Scanner(System.in);

        // Allow the user to add entries to the HashMap
        System.out.println("Enter student ID and name (type 'done' when finished):");

        while (true) {
            System.out.print("Enter student ID: ");
            String idInput = scanner.nextLine();

            // Check if the user wants to stop entering data
            if (idInput.equalsIgnoreCase("done")) {
                break;
            }

            // Convert ID to integer
            try {
                int id = Integer.parseInt(idInput);

                System.out.print("Enter student name: ");
                String name = scanner.nextLine();

                // Add the entry to the HashMap
                studentMap.put(id, name);
            } catch (NumberFormatException e) {
                System.out.println("Invalid ID. Please enter a valid integer for the student ID.");
            }
        }

        // Allow the user to retrieve and display a name based on an entered ID
        System.out.print("\nEnter a student ID to retrieve the name: ");
        int searchID = scanner.nextInt();

        // Retrieve and display the name for the given ID
        if (studentMap.containsKey(searchID)) {
            System.out.println("Student name: " + studentMap.get(searchID));
        } else {
            System.out.println("Student ID not found.");
        }

        // Close the scanner to prevent resource leak
        scanner.close();
    }
}
