import java.util.Scanner;

public class DivisionByZeroExample {

    public static void main(String[] args) {
        // Create a scanner object to read user input
        Scanner scanner = new Scanner(System.in);

        try {
            // Prompt the user for two integers
            System.out.print("Enter the first integer: ");
            int num1 = scanner.nextInt();
            System.out.print("Enter the second integer: ");
            int num2 = scanner.nextInt();

            // Attempt to divide num1 by num2
            int result = num1 / num2;

            // If no exception occurs, display the result
            System.out.println("Result: " + result);
        } catch (ArithmeticException e) {
            // Catch and handle ArithmeticException (e.g., division by zero)
            System.out.println("Error: Cannot divide by zero!");
        } finally {
            // Close the scanner to prevent resource leak
            scanner.close();
        }
    }
}
