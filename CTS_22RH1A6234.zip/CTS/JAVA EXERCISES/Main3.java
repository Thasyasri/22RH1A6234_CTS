public class Main3 {
    public static void main(String[] args) {
        // Create StudentDAO object to interact with the database
        StudentDAO studentDAO = new StudentDAO();

        // Insert a new student
        Student newStudent = new Student(0, "John Doe", 20); // ID is set to 0 as it's auto-generated
        studentDAO.insertStudent(newStudent);

        // Update an existing student's details
        Student existingStudent = new Student(1, "Alice Johnson", 22); // Assume student with ID 1 exists
        studentDAO.updateStudent(existingStudent);
    }
}
