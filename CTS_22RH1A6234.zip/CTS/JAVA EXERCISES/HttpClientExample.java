import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.io.IOException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class HttpClientExample {

    public static void main(String[] args) {
        // GitHub API endpoint for a user (e.g., GitHub's public API)
        String url = "https://api.github.com/users/octocat"; // Change to any GitHub user API
        
        // Create HttpClient
        HttpClient client = HttpClient.newHttpClient();

        // Create an HTTP request
        HttpRequest request = HttpRequest.newBuilder()
            .uri(URI.create(url))
            .build();

        try {
            // Send the GET request and get the response
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            // Print the HTTP status code
            System.out.println("Response Code: " + response.statusCode());

            // Print the response body
            String responseBody = response.body();
            System.out.println("Response Body: " + responseBody);

            // Optional: Parse the JSON response using Jackson
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode rootNode = objectMapper.readTree(responseBody);
            String name = rootNode.get("name").asText();
            int publicRepos = rootNode.get("public_repos").asInt();

            System.out.println("User's Name: " + name);
            System.out.println("Public Repositories: " + publicRepos);

        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}
