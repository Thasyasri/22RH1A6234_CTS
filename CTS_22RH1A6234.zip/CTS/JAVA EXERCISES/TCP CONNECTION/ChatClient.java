import java.io.*;
import java.net.*;

public class ChatClient {

    public static void main(String[] args) {
        // Client setup
        try (Socket socket = new Socket("localhost", 12345)) {
            System.out.println("Connected to the server.");

            // Get input and output streams for communication
            InputStream input = socket.getInputStream();
            OutputStream output = socket.getOutputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(input));
            PrintWriter writer = new PrintWriter(output, true);

            // Create a thread for receiving server messages
            Thread readThread = new Thread(() -> {
                try {
                    String message;
                    while ((message = reader.readLine()) != null) {
                        System.out.println("Server: " + message);
                    }
                } catch (IOException e) {
                    System.out.println("Error reading from server: " + e.getMessage());
                }
            });
            readThread.start();

            // Read from the console and send to the server
            BufferedReader consoleReader = new BufferedReader(new InputStreamReader(System.in));
            String clientMessage;
            while ((clientMessage = consoleReader.readLine()) != null) {
                writer.println("Client: " + clientMessage);
            }

        } catch (IOException e) {
            System.out.println("Error connecting to the server: " + e.getMessage());
        }
    }
}

