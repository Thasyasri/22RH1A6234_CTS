import java.io.*;
import java.net.*;

public class ChatServer {

    public static void main(String[] args) {
        // Server setup
        try (ServerSocket serverSocket = new ServerSocket(12345)) {
            System.out.println("Server is listening on port 12345...");

            // Accept client connection
            try (Socket socket = serverSocket.accept()) {
                System.out.println("Client connected: " + socket.getInetAddress());

                // Get input and output streams for communication
                InputStream input = socket.getInputStream();
                OutputStream output = socket.getOutputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(input));
                PrintWriter writer = new PrintWriter(output, true);

                // Create a thread for receiving client messages
                Thread readThread = new Thread(() -> {
                    try {
                        String message;
                        while ((message = reader.readLine()) != null) {
                            System.out.println("Client: " + message);
                        }
                    } catch (IOException e) {
                        System.out.println("Error reading from client: " + e.getMessage());
                    }
                });
                readThread.start();

                // Read from the console and send to the client
                BufferedReader consoleReader = new BufferedReader(new InputStreamReader(System.in));
                String serverMessage;
                while ((serverMessage = consoleReader.readLine()) != null) {
                    writer.println("Server: " + serverMessage);
                }
            } catch (IOException e) {
                System.out.println("Error in client connection: " + e.getMessage());
            }
        } catch (IOException e) {
            System.out.println("Error setting up server: " + e.getMessage());
        }
    }
}
