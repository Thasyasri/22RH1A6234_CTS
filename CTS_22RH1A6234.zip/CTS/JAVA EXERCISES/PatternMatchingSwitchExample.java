public class PatternMatchingSwitchExample {

    public static void main(String[] args) {
        // Testing the method with different object types
        printObjectType(10);        // Integer
        printObjectType("Hello");   // String
        printObjectType(3.14);      // Double
        printObjectType(true);      // Boolean
        printObjectType(new Object()); // Object
    }

    // Method to check the type of an object using a switch expression
    public static void printObjectType(Object obj) {
        switch (obj) {
            case Integer i -> System.out.println("This is an Integer: " + i);
            case String s -> System.out.println("This is a String: " + s);
            case Double d -> System.out.println("This is a Double: " + d);
            case Boolean b -> System.out.println("This is a Boolean: " + b);
            default -> System.out.println("This is an unknown type: " + obj.getClass().getName());
        }
    }
}
