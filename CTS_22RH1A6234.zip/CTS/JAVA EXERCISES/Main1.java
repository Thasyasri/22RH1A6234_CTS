// Base class Animal
class Animal {
    // Method in the Animal class
    public void makeSound() {
        System.out.println("Some generic animal sound");
    }
}

// Subclass Dog that inherits from Animal
class Dog extends Animal {
    // Override the makeSound method in the Dog class
    @Override
    public void makeSound() {
        System.out.println("Bark");
    }
}

public class Main1 {
    public static void main(String[] args) {
        // Create an Animal object and call the makeSound method
        Animal animal = new Animal();
        System.out.println("Animal sound:");
        animal.makeSound();
        
        // Create a Dog object and call the overridden makeSound method
        Dog dog = new Dog();
        System.out.println("Dog sound:");
        dog.makeSound();
    }
}
