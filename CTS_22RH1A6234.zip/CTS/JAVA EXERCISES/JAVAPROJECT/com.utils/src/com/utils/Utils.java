package com.utils;

public class Utils {
    public static String getGreetingMessage(String name) {
        return "Hello, " + name + "!";
    }
}
