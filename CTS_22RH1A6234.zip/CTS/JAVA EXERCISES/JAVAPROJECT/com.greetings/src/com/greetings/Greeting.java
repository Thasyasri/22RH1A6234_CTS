package com.greetings;

import com.utils.Utils;

public class Greeting {
    public static void main(String[] args) {
        String name = "Alice";
        String message = Utils.getGreetingMessage(name);
        System.out.println(message);
    }
}
