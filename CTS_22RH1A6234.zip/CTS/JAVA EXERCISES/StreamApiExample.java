import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class StreamApiExample {

    public static void main(String[] args) {
        // Create a list of integers
        List<Integer> numbers = new ArrayList<>();
        numbers.add(1);
        numbers.add(2);
        numbers.add(3);
        numbers.add(4);
        numbers.add(5);
        numbers.add(6);
        numbers.add(7);
        numbers.add(8);
        
        // Use Stream API to filter even numbers
        List<Integer> evenNumbers = numbers.stream()
                                           .filter(num -> num % 2 == 0) // Filter even numbers
                                           .collect(Collectors.toList()); // Collect the result into a list
        
        // Display the result
        System.out.println("Even numbers: " + evenNumbers);
    }
}
