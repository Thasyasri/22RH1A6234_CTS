// Define a class that extends Thread
class MyThread extends Thread {
    // The run method defines the task that the thread will execute
    @Override
    public void run() {
        // Print a message multiple times
        for (int i = 0; i < 5; i++) {
            System.out.println(Thread.currentThread().getName() + " - Message " + (i + 1));
            try {
                // Sleep for 500 milliseconds to simulate work and allow other threads to execute
                Thread.sleep(500);
            } catch (InterruptedException e) {
                System.out.println(e.getMessage());
            }
        }
    }
}

public class ThreadCreationExample {
    public static void main(String[] args) {
        // Create two threads
        MyThread thread1 = new MyThread();
        MyThread thread2 = new MyThread();
        
        // Start both threads
        thread1.start();
        thread2.start();
        
        // Optionally, wait for both threads to finish before printing the final message
        try {
            thread1.join();
            thread2.join();
        } catch (InterruptedException e) {
            System.out.println(e.getMessage());
        }
        
        System.out.println("Both threads have completed.");
    }
}
