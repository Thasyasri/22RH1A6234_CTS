import java.util.Scanner;

public class StringReversal {
    public static void main(String[] args) {
        // Create a Scanner object for user input
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter a string
        System.out.print("Enter a string: ");
        String inputString = scanner.nextLine();

        // Use StringBuilder to reverse the string
        StringBuilder reversedString = new StringBuilder(inputString);
        reversedString.reverse();  // Reverse the string

        // Display the reversed string
        System.out.println("Reversed string: " + reversedString);

        // Close the scanner
        scanner.close();
    }
}
