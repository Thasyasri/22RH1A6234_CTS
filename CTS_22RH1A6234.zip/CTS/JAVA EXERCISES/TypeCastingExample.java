public class TypeCastingExample {
    public static void main(String[] args) {
        // Declare a double variable with a decimal value
        double doubleValue = 9.75;

        // Cast the double to an int (this will truncate the decimal part)
        int intValue = (int) doubleValue;

        // Display the result of casting from double to int
        System.out.println("Double value: " + doubleValue);
        System.out.println("After casting to int: " + intValue);

        // Declare an int variable
        int intVariable = 5;

        // Cast the int to a double
        double newDoubleValue = (double) intVariable;

        // Display the result of casting from int to double
        System.out.println("Int value: " + intVariable);
        System.out.println("After casting to double: " + newDoubleValue);
    }
}
