import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class FileReadingExample {

    public static void main(String[] args) {
        // Path to the file to read
        String fileName = "output.txt";

        // Try block for reading data from the file
        try (BufferedReader bufferedReader = new BufferedReader(new FileReader(fileName))) {
            String line;
            
            // Read each line from the file and display it on the console
            while ((line = bufferedReader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            // Handle any IO exceptions
            System.out.println("An error occurred while reading the file: " + e.getMessage());
        }
    }
}
