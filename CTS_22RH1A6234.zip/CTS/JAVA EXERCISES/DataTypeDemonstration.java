public class DataTypeDemonstration {
    public static void main(String[] args) {
        // Declare variables of different primitive types
        int intValue = 42;             // Integer type
        float floatValue = 3.14f;      // Float type (note the 'f' at the end)
        double doubleValue = 3.14159;  // Double type
        char charValue = 'A';          // Char type
        boolean booleanValue = true;   // Boolean type

        // Display the values of the variables
        System.out.println("Integer value: " + intValue);
        System.out.println("Float value: " + floatValue);
        System.out.println("Double value: " + doubleValue);
        System.out.println("Char value: " + charValue);
        System.out.println("Boolean value: " + booleanValue);
    }
}
