// Define the Playable interface
interface Playable {
    // Method declaration
    void play();
}

// Class Guitar implements Playable interface
class Guitar implements Playable {
    // Provide implementation of play method
    @Override
    public void play() {
        System.out.println("Playing the guitar: Strum strum");
    }
}

// Class Piano implements Playable interface
class Piano implements Playable {
    // Provide implementation of play method
    @Override
    public void play() {
        System.out.println("Playing the piano: Tink tink");
    }
}

public class Main2 {
    public static void main(String[] args) {
        // Instantiate Guitar and Piano objects
        Playable guitar = new Guitar();
        Playable piano = new Piano();
        
        // Call the play method for each object
        System.out.println("Guitar sound:");
        guitar.play();
        
        System.out.println("Piano sound:");
        piano.play();
    }
}
