// Define the Car class
class Car {
    // Attributes
    String make;
    String model;
    int year;
    
    // Constructor to initialize the attributes
    public Car(String make, String model, int year) {
        this.make = make;
        this.model = model;
        this.year = year;
    }
    
    // Method to display car details
    public void displayDetails() {
        System.out.println("Car Make: " + make);
        System.out.println("Car Model: " + model);
        System.out.println("Car Year: " + year);
    }
}

public class Main {
    public static void main(String[] args) {
        // Create Car objects
        Car car1 = new Car("Toyota", "Corolla", 2020);
        Car car2 = new Car("Ford", "Mustang", 2021);
        
        // Call the displayDetails method to print car information
        System.out.println("Car 1 Details:");
        car1.displayDetails();
        System.out.println();
        
        System.out.println("Car 2 Details:");
        car2.displayDetails();
    }
}
