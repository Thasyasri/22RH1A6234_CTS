import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class VirtualThreadsExample {

    public static void main(String[] args) {
        // Measure performance of virtual threads
        long startTime = System.currentTimeMillis();
        launchVirtualThreads(100000);  // Launch 100,000 virtual threads
        long endTime = System.currentTimeMillis();
        System.out.println("Virtual Threads execution time: " + (endTime - startTime) + " ms");

        // Measure performance of traditional threads
        startTime = System.currentTimeMillis();
        launchTraditionalThreads(100000);  // Launch 100,000 traditional threads
        endTime = System.currentTimeMillis();
        System.out.println("Traditional Threads execution time: " + (endTime - startTime) + " ms");
    }

    // Launch virtual threads
    public static void launchVirtualThreads(int numThreads) {
        for (int i = 0; i < numThreads; i++) {
            Thread.startVirtualThread(() -> {
                System.out.println("Virtual thread executing");
            });
        }
    }

    // Launch traditional threads
    public static void launchTraditionalThreads(int numThreads) {
        ExecutorService executor = Executors.newFixedThreadPool(10);  // Fixed thread pool
        for (int i = 0; i < numThreads; i++) {
            executor.submit(() -> {
                System.out.println("Traditional thread executing");
            });
        }
        executor.shutdown();
    }
}
